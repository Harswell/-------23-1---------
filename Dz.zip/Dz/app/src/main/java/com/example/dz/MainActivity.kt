package com.example.dz
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private lateinit var mainTextView: TextView
    private lateinit var nameInput: EditText
    private lateinit var helloButton: Button
    private lateinit var resultText: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        mainTextView = findViewById(R.id.main_textview)
        mainTextView.text = "Set in java!"
        nameInput = findViewById(R.id.name_input)
        helloButton = findViewById(R.id.hello_button)
        resultText = findViewById(R.id.result_text)
        helloButton.setOnClickListener{
            val name = nameInput.text.toString()
            val surname = "Степанов"
            val group = "ИСп23-1"
            val hui = 10
            resultText.text = "Привет, $name $surname, из группы $group"
        }

        }
    }
